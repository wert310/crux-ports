* smarter ambiguity check for partial hints
* improved matching capabilities (not just urls)
* scrollback search needs to be improved upstream [1]_
* expose keybindings in ``termite.cfg``
* keyboard selection should handle wrapped lines properly

.. [1] https://bugzilla.gnome.org/show_bug.cgi?id=627886
